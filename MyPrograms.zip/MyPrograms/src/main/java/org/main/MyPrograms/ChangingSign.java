package org.main.MyPrograms;

public class ChangingSign {
public int ChangeSign(int n)
{
	return n*-1;
}
}
