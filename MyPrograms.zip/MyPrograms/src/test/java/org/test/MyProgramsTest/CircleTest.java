package org.test.MyProgramsTest;

import org.junit.Test;
public class CircleTest {
	
	@Test
	public void circleTest(){
		
	}
	
}
