package org.test.MyProgramsTest;

import static org.junit.Assert.*;

import org.junit.Test;
import org.main.MyPrograms.Test1;

public class Testtest {

	@Test
	public void test() {
		Test1 test = new Test1();
		test.sumOfBigNum("123456789123456789", "123456789123456789");
	}

}
